function dummy(text, callback) {
  callback(text || mozIndexedDB);
}

exports.dummy = dummy;

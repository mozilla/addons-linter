function dummy(text, callback) {
  alert('eh ya a_hole');
  callback(text);
}

exports.dummy = dummy;

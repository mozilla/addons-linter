function dummy(text, callback) {
  alert('eh ya assholes');
  callback(text);
}

exports.dummy = dummy;

function dummy(text, callback) {
  alert('eh ya ahole');
  callback(text);
}

exports.dummy = dummy;

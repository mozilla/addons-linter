function dummy(text, callback) {
  callback(text);
}

exports.dummy = dummy;

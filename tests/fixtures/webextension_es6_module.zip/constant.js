export const HELLO = 'Hello';
export const ES_MODULE = 'ES module';

import {ES_MODULE, HELLO} from './constant.js';

document.addEventListener("DOMContentLoaded", () => {
  console.log(`${HELLO} ${ES_MODULE}!`);
});

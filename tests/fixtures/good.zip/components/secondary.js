var message = 'Welcome to my app.';

console.log(message);

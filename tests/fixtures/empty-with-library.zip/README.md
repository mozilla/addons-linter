#Rent Controls
A basic add-on